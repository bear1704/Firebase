package com.example.aca.login.adapters;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.aca.login.R;
import com.example.aca.login.models.User;

import java.util.ArrayList;
import java.util.List;

public class FriendListAdapter extends RecyclerView.Adapter<FriendListAdapter.FriendHolder>
{

    public static final int UNSELECTION_MODE = 1; //체크박스를 사용하지 않는 모드
    public static final int SELECTION_MODE = 2; //사용하는 모드
    private List<User> mCheckedUserList = new ArrayList<>();


    private int selectionMode = UNSELECTION_MODE;

    private ArrayList<User> friendList; //친구목록(User 형태) 배열리스트

    public FriendListAdapter()
    {
        friendList = new ArrayList<>();  //생성자 초기화
    }

    public void addItem(User user)
    {
        friendList.add(user);
        notifyDataSetChanged();  //친구 목록 리스트에 User를 추가한 뒤, 리스너에게 데이터가 변경되었음을 알린다.
    }

    public void setSelectionMode(int selectionMode)
    {
        this.selectionMode = selectionMode;
        notifyDataSetChanged();  //데이터셋이 변경되었음을 리스너에게 알림
    }

    public int getSelectionMode()
    {
        return this.selectionMode;
    }

    public User getItem(int position)
    {
        return this.friendList.get(position);
    }



    @Override
    public FriendHolder onCreateViewHolder(ViewGroup parent, int viewType) //뷰홀더 생성시에 적용하는 부분
    {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_friend_item, parent, false);

        FriendHolder friendHolder = new FriendHolder(view); //뷰홀더에 뷰끼워넣기
        return friendHolder;
    }

    @Override
    public void onBindViewHolder(FriendHolder holder, int position)
    {
        User friend = getItem(position);
/*

       Log.d("CHECKED__", "->>" + holder.friendSelectCheckbox.isChecked()  +  "   name : " + holder.mNameView.getText().toString());
        if(holder.friendSelectCheckbox.isChecked())
            friend.setSelection(true);
        else
            friend.setSelection(false);

            //2안이었던 것
*/

        if(friend.isSelection())
            holder.friendSelectCheckbox.setChecked(true);
        else
            holder.friendSelectCheckbox.setChecked(false);


        holder.mEmailView.setText(friend.getEmail());
        holder.mNameView.setText(friend.getName());

        if(getSelectionMode() == UNSELECTION_MODE)
            holder.friendSelectCheckbox.setVisibility(View.GONE);
        else
            holder.friendSelectCheckbox.setVisibility(View.VISIBLE);

        if(friend.getProfileUrl() != null)
        {
            Glide.with(holder.itemView)
                    .load(friend.getProfileUrl())
                    .into(holder.mProfileView);
        }



    }

    @Override
    public int getItemCount()
    {
        return friendList.size();
    }

    public int getSelectionUserCount()
    {
        int selectedCount = 0;
        for(User user : friendList)
        {
            if(user.isSelection())
                selectedCount++;
        }

        return selectedCount;
    }

    public String[] getSelectedUids()
    {
        String[] selectedUids = new String[getSelectionUserCount()];
        int i = 0;

        for(User user : friendList)
        {
            if(user.isSelection()) // for문 안의 유저가 체크박스 선택된 개체일때
            {
                selectedUids[i++] = user.getUid();
                Log.v("UIDS__", selectedUids[0]);
            }
        }

        return selectedUids;
    }



    public static class FriendHolder extends RecyclerView.ViewHolder   //리사이클러뷰를 사용하기 위한 뷰홀더 정의
    {
            CheckBox friendSelectCheckbox;  //RecyclerView의 Item에 들어가는 모든 뷰를 정의하여 선언해 놓는다.
            ImageView mProfileView;
            TextView mNameView;
            TextView mEmailView;

        public FriendHolder(View v) //뷰 선언 생성자
        {
            super(v);
            friendSelectCheckbox = (CheckBox) v.findViewById(R.id.checkbox);
            mProfileView = (ImageView) v.findViewById(R.id.thumbnail);
            mNameView = (TextView) v.findViewById(R.id.name);
            mEmailView = (TextView) v.findViewById(R.id.email);

        }

    }

}
