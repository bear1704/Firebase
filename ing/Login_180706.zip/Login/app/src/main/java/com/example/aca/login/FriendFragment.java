/***********************************
 *
 *
 *
 */


package com.example.aca.login;

import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.example.aca.login.adapters.FriendListAdapter;
import com.example.aca.login.comtomviews.RecyclerViewItemClickListener;
import com.example.aca.login.models.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Iterator;

public class FriendFragment extends Fragment
{

    private EditText etEmail;
    private FirebaseUser mFirebaseUser;  // Doc 혹은 구글링 참조
    private FirebaseAuth mFirebaseAuth;
    private FirebaseDatabase mFirebaseDb;
    private DatabaseReference mFriendDbRef;
    private DatabaseReference mUserDbRef; //DB를 레퍼런스(참조)하고싶을때 사용하는 데이터타입
    private LinearLayout liFriendMain;


    private boolean successAddFriends = false;   //친구 추가에 성공/실패했냐를 판별하는 부울변수
    private FriendListAdapter friendListAdapter;
    private RecyclerView mRecyclerView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState)
    {
        View friendView = inflater.inflate(R.layout.fragment_friend, container, false);
        liFriendMain = (LinearLayout) friendView.findViewById(R.id.friend_fragment_main);


        etEmail = (EditText) friendView.findViewById(R.id.et_input_email);
        Button searchEmail = (Button) friendView.findViewById(R.id.btn_search_email);

        mFirebaseAuth = FirebaseAuth.getInstance();
        mFirebaseUser = mFirebaseAuth.getCurrentUser();
        mFirebaseDb = FirebaseDatabase.getInstance();
       // mFriendDbRef = mFirebaseDb.getReference("users"+mFirebaseUser.getUid() + "friends"); //currentUser(사용자 자신)의 friends 항목을 모두 가져온다.
        mFriendDbRef =mFirebaseDb.getReference("users").child(mFirebaseUser.getUid()).child("friends"); //currentUser(사용자 자신)의 friends 항목을 모두 가져온다.
        mUserDbRef = mFirebaseDb.getReference("users"); // FirebaseDB의 모든 users를 가져온다.

        searchEmail.setOnClickListener(new View.OnClickListener()  //"찾기"버튼을 누를 시 작동하는 리스너
        {
            @Override
            public void onClick(View view)
            {
                addFriend(); //친구 추가 함수(하단에 있음)
            }
        });

        addFriendListener();
        friendListAdapter = new FriendListAdapter();

        mRecyclerView = (RecyclerView) friendView.findViewById(R.id.rv_friendRecyclerView);  //리사이클러뷰를 ID를 통해 가져와서
        mRecyclerView.setAdapter(friendListAdapter); //어댑터를 장착한다
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        mRecyclerView.addOnItemTouchListener(new RecyclerViewItemClickListener(getContext(), new RecyclerViewItemClickListener.OnItemClickListener()
        {
            @Override
            public void onItemClick(View view, int position)
            {

                final User friend = friendListAdapter.getItem(position); //프렌드 리스트에서, position(터치위치)에 해당하는 유저정보를 가져온다
                //friendListAdapter.notifyItemChanged(position);   // 2안이었던 것

               if(friendListAdapter.getItem(position).isSelection())
               {
                   friendListAdapter.getItem(position).setSelection(false);
                   friendListAdapter.notifyItemChanged(position);
               }
               else
               {
                   friendListAdapter.getItem(position).setSelection(true);
                   friendListAdapter.notifyItemChanged(position);
               }

                if(friendListAdapter.getSelectionMode() == FriendListAdapter.UNSELECTION_MODE)  //체크박스가 없는, 단일 선택 모드
                {  //단일 선택 때 체크박스가 GONE 상태일 때 체크박스가 체크되는 것 같은 문제 요소가 있음.
                    Snackbar.make(view, friend.getName() + "님과 대화하시겠습니까? ", Snackbar.LENGTH_INDEFINITE).setAction("확인",
                            new View.OnClickListener(){
                                @Override
                                public void onClick(View view)
                                {
                                    Intent intent= new Intent(getActivity(), ChatActivity.class);
                                    intent.putExtra("uid", friend.getUid());
                                    startActivityForResult(intent, ChatFragment.JOIN_ROOM_REQUEST_CODE);
                                }
                            }).show();
                }
                else   //체크박스가 있는, 다중 선택 모드
                {


                    int selectedCount = friendListAdapter.getSelectionUserCount();
                    Log.d("GETSELECTION__", "== > "+  selectedCount);

                    final Snackbar multipleChatSnackbar = Snackbar.make(view, selectedCount + " 명과 단체 대화를 하시겠습니까? ", Snackbar.LENGTH_INDEFINITE).setAction("확인", new View.OnClickListener()
                    {
                        @Override
                        public void onClick(View view)
                        {
                            Intent intent = new Intent(getActivity(), ChatActivity.class);
                            intent.putExtra("uids", friendListAdapter.getSelectedUids());
                            startActivityForResult(intent, ChatFragment.JOIN_ROOM_REQUEST_CODE);
                        }
                    });

                    if(selectedCount != 0)
                    {
                        //Log.d("SELECTED__", "count :: " + selectedCount );
                        multipleChatSnackbar.show();
                    }
                    else
                    {
                        Log.d("SELECTED__", "count :: " + selectedCount );
                        //multipleChatSnackbar.dismiss(); //dismiss 미작동
                        Snackbar.make(view,"취소되었습니다.",Snackbar.LENGTH_SHORT).show();
                    }
                }

                //미구현
            }
        }));

        return friendView;
    }


    public void addFriend()
    {
        successAddFriends = false; // 친구등록 성공정보 초기화
        final String inputEmail = etEmail.getText().toString();  // 사용자가 입력한 이메일을 가져옵니다. final을 하는 이유는 이후에 또 사용될 수 있으므로 함수가 끝나도 사라지지 않게 하기위해
        //이메일이 입력되지 않았다면, 안내 메시지를 보여줍니다.
        if(inputEmail.isEmpty())
        {
            Log.d("DATA_INSERT", "이메일 입력여부 판정");
            Snackbar.make(liFriendMain, "먼저 이메일을 입력하세요", Snackbar.LENGTH_SHORT).show();
            return;
        }
        //자기 자신이 친구로 등록되지 않게 막습니다
        if(mFirebaseUser.getEmail().equals(inputEmail))
        {
            Log.d("DATA_INSERT", "자기 자신 판정");
            Snackbar.make(liFriendMain, "자기 자신은 친구로 등록할 수 없습니다", Snackbar.LENGTH_SHORT).show();
            return;
        }


        mFriendDbRef.addListenerForSingleValueEvent(new ValueEventListener() // 한 번의 데이터 읽기 후 폐기되는 리스너, 사용자의 Friend를 읽어와 사용하려고 만듦
        {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) //리스너가 연결될 최초 한 번, 그 후로 데이터가 변경될때 호출됨
            {
                Log.d("DATA_INSERT", "데이터베이스에서 프렌드 읽어오기, 이미 친구인 사용자 확인");
                Iterable<DataSnapshot> friendsIterable = dataSnapshot.getChildren(); //프렌드 하단의 유저 정보를 반복자를 사용해 불러온다.
                Iterator<DataSnapshot> friendsIterator = friendsIterable.iterator(); //users/<Uid>/friends/user정보
                while(friendsIterator.hasNext())
                {
                    User user = friendsIterator.next().getValue(User.class);  //getValue를 통해, User 클래스 객체 형식대로 반복자의 정보를 가져온다.
                                                                //User.class는 Firebase를 위해 정의된 형태가 있으며, 필요에 따라 프로퍼티를 몇 개 무시할 수도 있다. @IgnoreExtraProperties
                    if(user.getEmail().equals(inputEmail))
                    {  // 이미 friends 데이터베이스에 있던 이메일이라면,
                        Snackbar.make(liFriendMain, "이미 친구인 사용자입니다." , Snackbar.LENGTH_SHORT).show();
                        return;
                    }
                }

                mUserDbRef.addListenerForSingleValueEvent(new ValueEventListener()  //이제 전체 유저 정보들 중, 입력 이메일이 있는지 없는지를 검사하자.
                {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot)
                    {
                        Log.d("DATA_INSERT", "전체 유저들 중 가입된 계정인지 확인");
                        Iterator<DataSnapshot> userIter = dataSnapshot.getChildren().iterator();

                        int DEBUG_DATA1 = (int) dataSnapshot.getChildrenCount();
                        Log.d("DATA_INSERT", "유저 데이터 숫자 : "+ DEBUG_DATA1);

                        while(userIter.hasNext())
                        {
                            Log.d("DATA_INSERT", "전체 유저 while");
                            final User currentUser = userIter.next().getValue(User.class);  //반복자가 가리키는 유저정보를 가져온다.

                            if(currentUser.getEmail().equals(inputEmail)) // 입력한 이메일과 그 유저정보의 이메일이 같으면 친구등록
                            {        Log.d("DATA_INSERT", "데이터 입력");
                                // users/{myuid}/friends/{someone_uid}/firebasePush/
                                // users/{someone_uid}/friends/{myuid}/firebasePush/
                                successAddFriends = true; // 성공정보를 미리 true로 바꾼다.
                                mFriendDbRef.push().setValue(currentUser, new DatabaseReference.CompletionListener() //setValue를 통해 나의 친구창에 친구정보를 등록하고, 성공여부를 진단
                                {

                                    @Override
                                    public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference)
                                    {  //상대 정보 등록에 성공했다면 이제 '상대 유저'의 friends 목록에 '현재 사용자 정보(내 정보)' 를 등록한다.
                                        mUserDbRef.child(mFirebaseUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener()
                                        {  //UserDbRef에 '현재 사용자 정보(내 정보)' 를 mFireBaseUser.getuid를 통해 얻어서,  레퍼런스를 가져옴.
                                            @Override
                                            public void onDataChange(DataSnapshot dataSnapshot)
                                            {
                                                User user = dataSnapshot.getValue(User.class);
                                                mUserDbRef.child(currentUser.getUid()).child("friends").push().setValue(user);
                                                Snackbar.make(liFriendMain, "친구등록이 완료되었습니다." , Snackbar.LENGTH_SHORT).show();


                                            }

                                            @Override
                                            public void onCancelled(DatabaseError databaseError)
                                            {

                                            }
                                        });
                                    }
                                });

                            }

                        }

                        if(successAddFriends == false)
                        {
                            Snackbar.make(liFriendMain, "해당 이메일은 가입하지 않은 유저입니다. ", Snackbar.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError)
                    {

                    }
                });



            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {

            }
        });



    }

    private void addFriendListener()
    {
        mFriendDbRef.addChildEventListener(new ChildEventListener()
        {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s)  //친구가 추가됨을 감지
            {
                User friend = dataSnapshot.getValue(User.class); //추가된 친구의 정보를, getValue를 통해 User의 형태로 가져온다.
                drawUI(friend);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) //친구 변경을 감지
            {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot)
            {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s)
            {

            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {

            }
        });

    }

    private void drawUI(User friend)
    {
        friendListAdapter.addItem(friend);
    }


    public void toggleSelectionMode()
    {
        friendListAdapter
                .setSelectionMode(friendListAdapter.getSelectionMode() == FriendListAdapter.SELECTION_MODE
                        ? friendListAdapter.UNSELECTION_MODE
                        : friendListAdapter.SELECTION_MODE);
    }
}
