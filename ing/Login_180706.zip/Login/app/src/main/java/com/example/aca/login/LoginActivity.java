/*
* 로그인 과정을 총괄하는 액티비티입니다. 현재는 Google만 구현되어 있습니다.
*
*
 */


package com.example.aca.login;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.aca.login.models.User;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity
{

    private FirebaseAuth mAuth;
    private SignInButton mSignInButton;
    private GoogleApiClient mGoogleAPIClient;   //The main entry point for Google Play services integration.
  //  private GoogleSignInOptions mGoogleSignInOptions;
    private static int GOOGLE_LOGIN_OPEN = 100;
    private static int LOGOUT = 101;
    private DatabaseReference mUserRef;
    private FirebaseDatabase mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mSignInButton = (SignInButton) findViewById(R.id.google_sign_in_btn);  //구글에서 지원하는 Sign In 버튼(로그인 버튼)

        Intent switchMain = new Intent(this, MainRoomActivity.class);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();   //현재 앱에 연결된 유저정보를 가져온다. 없으면 null

        if(currentUser != null)
        {// LoginUI에서, 이미 로그인되어있을경우 바로 액티비티 전환하고 로그인 액티비티 클로즈
            Toast.makeText(this,"이미 로그인 되어 있음", Toast.LENGTH_SHORT);
            startActivity(switchMain);
            finish();
            return;
        }

        mDatabase = FirebaseDatabase.getInstance();
        mUserRef = FirebaseDatabase.getInstance().getReference("users");

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)  //GoogleSignInOptions is options used to configure the GOOGLE_SIGN_IN_API.
                .requestIdToken(getString(R.string.default_web_client_id)) // 웹클라이언트 키 전송 Specifies that an ID token for authenticated users is requested.
                .requestEmail()  //Specifies that user ID is requested by your application.
                .build();
            //SIGn_IN 설정값 조정

        mGoogleAPIClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this /* FragmentActivity */, new GoogleApiClient.OnConnectionFailedListener()
                {

                    @Override
                    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
                        // 실패 시 처리 하는 부분.
                    }
                })
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();

        mSignInButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(LoginActivity.this,"BtnOnclicked", Toast.LENGTH_SHORT).show();
                signIn();
            }
        });

    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == GOOGLE_LOGIN_OPEN)
        {  //Signin버튼을 눌러서, signin 메소드를 통해 보낸 Intent를 받아 구글 로그인 성공여부ㅡㄹ 확인
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);   //Helper function to extract out GoogleSignInResult from the onActivityResult(int, int, Intent) for Sign In
                                                                                        //GoogleSignInResult객체를 가져오기 위한 코드.getSignInResultFromIntent
            if (result.isSuccess()) {
                // Google Sign In was successful, authenticate with Firebase : 구글 계정 로그인에 성공하여, 파이어베이스에 입력해야 하는 상태.
                GoogleSignInAccount account = result.getSignInAccount();
               firebaseAuthWithGoogle(account);  //바로 아래에 있는거(구글 인증과정, 인증성공후)
            } else {
                // Google Sign In failed, update UI appropriately
                // ...
            }
        }

    }

    private void firebaseAuthWithGoogle(GoogleSignInAccount acct)
    {
        Log.d("LOGIN", "firebaseAuthWithGoogle:" + acct.getId());

        AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful())
                        {
                            // Sign in success, update UI with the signed-in user's information

                            FirebaseUser firebaseUser = task.getResult().getUser();  //구글 로그인이 성공하였다면, 파이어베이스의 데이터베이스에
                            final User saveUser = new User();   //해당 정보들을 저장해야 한다. User class 형태로 데이터를 만들어서 Email, Name, Uid를 입력하고 저장한다.
                            saveUser.setEmail(firebaseUser.getEmail());
                            saveUser.setName(firebaseUser.getDisplayName());
                            saveUser.setUid(firebaseUser.getUid());
                            if(firebaseUser.getPhotoUrl() != null) // 프로필 사진은 있을수도, 없을수도 있기 때문에 조건문으로 crash를 방지한다.
                            {
                                saveUser.setProfileUrl(firebaseUser.getPhotoUrl().toString());
                            }


                            mUserRef.child(saveUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener()
                            {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot)
                                {
                                    if(!dataSnapshot.exists()) //로그인 정보가 없을때
                                    {
                                        mUserRef.child(saveUser.getUid()).setValue(saveUser, new DatabaseReference.CompletionListener()
                                        {

                                            @Override
                                            public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) //로그인 정보가 없을때만 새로 저장된다.
                                            {
                                                Log.d("LOGINSTATUS", "정상적으로 저장되었음");
                                                Log.d("LOGINSTATUS" , "login success");
                                                //FirebaseUser user = mAuth.getCurrentUser();

                                                Intent intent = new Intent(LoginActivity.this, MainRoomActivity.class);  //저장이 끝나면 Mainroom으로 이동
                                                startActivity(intent);
                                                finish();
                                                return;
                                            }
                                        });
                                    }
                                    else
                                    {
                                        Intent intent = new Intent(LoginActivity.this, MainRoomActivity.class);  //로그인 정보가 있을땐 그냥 점프
                                        startActivity(intent);
                                        finish();
                                        return;
                                    }
                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError)
                                {
                                }
                            });

                        }
                        else
                            {
                            // If sign in fails, display a message to the user.

                            Toast.makeText(LoginActivity.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                            //updateUI(null);
                             }

                        // ...
                    }
                });
    }




    private void signIn()
    {
        Toast.makeText(this,"SignIn 함수 작동111", Toast.LENGTH_SHORT).show();
        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleAPIClient);
        startActivityForResult(signInIntent, GOOGLE_LOGIN_OPEN);
        Toast.makeText(this,"SignIn 함수 작동", Toast.LENGTH_SHORT).show();
    }


}
