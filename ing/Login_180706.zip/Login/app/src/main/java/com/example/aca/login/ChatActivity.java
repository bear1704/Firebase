package com.example.aca.login;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

//import com.example.aca.login.R;

public class ChatActivity extends AppCompatActivity
{
    public void onCreate(Bundle saveInstancestate)
    {
        super.onCreate(saveInstancestate);
        setContentView(R.layout.activity_chat);

        String uid = getIntent().getStringExtra("uid");
        String[] uids = getIntent().getStringArrayExtra("uids");
    }

}
