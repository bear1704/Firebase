package com.example.aca.login;


import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;



public class ChatFragment extends Fragment
{
    public static final int JOIN_ROOM_REQUEST_CODE = 100;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState)
    {
        View chatView = inflater.inflate(R.layout.fragment_chat, container, false);

        return chatView;
    }

}
