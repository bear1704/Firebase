package com.example.aca.login;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class MainRoomActivity extends AppCompatActivity implements View.OnClickListener
{


    private ViewPagerAdapter mPageAdapter; //
    private ViewPager mViewPager; // Friend, Chatting 두 가지의 Fragment를 표시하기 위한 뷰페이저.
    private TabLayout mTabLayout; // 뷰페이저를 상단 탭을 더하여 보여주기 위한 탭레이아웃
    private FloatingActionButton mFab;


    @Override
    protected void onCreate(Bundle saveInstanceState)
    {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_main_room);

        mViewPager = findViewById(R.id.vp_mainRoomViewPager);
        setupViewPager();

        mTabLayout = findViewById(R.id.tb_main_room);
        mTabLayout.setupWithViewPager(mViewPager);  //만들어진 뷰페이저에 탭을 세팅한다.

        mFab = (FloatingActionButton) findViewById(R.id.fab);
        mFab.setOnClickListener(this);


    }

    @Override
    public void onClick(View view)
    {
        switch(view.getId())
        {
            case R.id.fab:
                FriendFragment friendFragment = (FriendFragment) mPageAdapter.getItem(1); // 프렌드 쪽의 페이지 프래그먼트를 받아온다.
                friendFragment.toggleSelectionMode();  //체크박스 GONE,VISIBLE 전환
                Log.d("ONCLICK_TEST", "fab 클릭됨");
                break;
        }
    }



    private void setupViewPager()
    {
        mPageAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        mPageAdapter.addFragment(new ChatFragment() , "채팅");
        mPageAdapter.addFragment(new FriendFragment(), "친구");

        mViewPager.setAdapter(mPageAdapter); //뷰페이저와 뷰페이저어댑터를 합친다.

    }



    private class ViewPagerAdapter extends FragmentPagerAdapter
    {

        private List<Fragment> fragmentList = new ArrayList<>();  // Friends, Chatting 두 개의 프래그먼트를 가지는 프래그먼트 리스트
        private List<String> fragmentTitleList = new ArrayList<>(); //프래그먼트들의 이름을 가지는 타이틀리스트

        public ViewPagerAdapter(FragmentManager fm)
        {
            super(fm);
        }

        @Override
        public Fragment getItem(int position)
        {
            return fragmentList.get(position);
        }

        @Override
        public String getPageTitle(int position)
        {
            return fragmentTitleList.get(position);
        }

        @Override
        public int getCount()
        {
            return fragmentList.size();
        }

        public void addFragment(Fragment frag, String str)
        {
            fragmentList.add(frag);
            fragmentTitleList.add(str);
        }
    }

}
