package com.example.aca.login;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

public class LoginActivity extends AppCompatActivity
{

    private FirebaseAuth mAuth;
    private SignInButton mSignInButton;
    private GoogleApiClient mGoogleAPIClient;   //The main entry point for Google Play services integration.
  //  private GoogleSignInOptions mGoogleSignInOptions;
    private static int GOOGLE_LOGIN_OPEN = 100;
    private static int LOGOUT = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mSignInButton = (SignInButton) findViewById(R.id.google_sign_in_btn);  //구글에서 지원하는 Sign In 버튼(로그인 버튼)

        Intent switchMain = new Intent(this, MainActivity.class);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();   //현재 앱에 연결된 유저정보를 가져온다. 없으면 null

        if(currentUser != null)
        {// LoginUI에서, 이미 로그인되어있을경우 바로 액티비티 전환하고 로그인 액티비티 클로즈
            Toast.makeText(this,"이미 로그인 되어 있음", Toast.LENGTH_SHORT);
            startActivity(switchMain);
            finish();
            return;
        }

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)  //GoogleSignInOptions is options used to configure the GOOGLE_SIGN_IN_API.
                .requestIdToken(getString(R.string.default_web_client_id)) // 웹클라이언트 키 전송 Specifies that an ID token for authenticated users is requested.
                .requestEmail()  //Specifies that user ID is requested by your application.
                .build();
            //SIGn_IN 설정값 조정

        mGoogleAPIClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this /* FragmentActivity */, new GoogleApiClient.OnConnectionFailedListener()
                {

                    @Override
                    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
                        // 실패 시 처리 하는 부분.
                    }
                })
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();

        mSignInButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(LoginActivity.this,"BtnOnclicked", Toast.LENGTH_SHORT).show();
                signIn();
            }
        });

    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == GOOGLE_LOGIN_OPEN)
        {  //Signin버튼을 눌러서, signin 메소드를 통해 보낸 Intent를 받아 구글 로그인 성공여부ㅡㄹ 확인
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);   //Helper function to extract out GoogleSignInResult from the onActivityResult(int, int, Intent) for Sign In
                                                                                        //GoogleSignInResult객체를 가져오기 위한 코드.getSignInResultFromIntent
            if (result.isSuccess()) {
                // Google Sign In was successful, authenticate with Firebase : 구글 계정 로그인에 성공하여, 파이어베이스에 입력해야 하는 상태.
                GoogleSignInAccount account = result.getSignInAccount();
               firebaseAuthWithGoogle(account);  //바로 아래에 있는거(구글 인증과정, 인증성공후)
            } else {
                // Google Sign In failed, update UI appropriately
                // ...
            }
        }

    }

    private void firebaseAuthWithGoogle(GoogleSignInAccount acct) {
        Log.d("LOGIN", "firebaseAuthWithGoogle:" + acct.getId());

        AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information

                            FirebaseUser user = mAuth.getCurrentUser();

                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                            return;

                        } else {
                            // If sign in fails, display a message to the user.

                            Toast.makeText(LoginActivity.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                            //updateUI(null);
                        }

                        // ...
                    }
                });
    }


    private void signIn()
    {
        Toast.makeText(this,"SignIn 함수 작동111", Toast.LENGTH_SHORT).show();
        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleAPIClient);
        startActivityForResult(signInIntent, GOOGLE_LOGIN_OPEN);
        Toast.makeText(this,"SignIn 함수 작동", Toast.LENGTH_SHORT).show();
    }


}
